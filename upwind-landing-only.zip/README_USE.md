
Minimalny wycinek szablonu Upwind (Next.js, TypeScript) zawierający TYLKO stronę "index-five" (sekcja z hasłem "Unique and bold functionality") oraz niezbędne komponenty i obrazy.
Uruchomienie:
1) npm i
2) npm run dev
